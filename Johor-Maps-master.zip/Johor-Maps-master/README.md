# Johor-Maps
Shapefiles, GeoJSON and Source Meta-datas for the state of Johor
Daerah Mengundi boundaries no longer applicable post 2015
